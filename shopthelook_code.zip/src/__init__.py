"""ShopTheLook source package."""
import os
import sys

# macOS: the PyPI wheels of torch and faiss-cpu each bundle their own libomp,
# and Intel's OpenMP aborts when it sees a second copy. We allow it, limit
# FAISS to a single thread (see src/index.py) so the two runtimes never run
# thread pools at the same time, and verify FAISS against an exact NumPy
# search in tests/test_retrieval.py.
if sys.platform == "darwin":
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
