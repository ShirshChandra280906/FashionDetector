"""Read selected members of a remote .zip over HTTP range requests.

DeepFashion2's train.zip is 10.6 GB, but we only need a ~15k-image subset.
A zip file keeps its table of contents (the "central directory") at the end,
so we can read that once (~30 MB), then fetch just the bytes of the members
we want. This keeps the download to roughly the size of the subset.
"""
from __future__ import annotations

import io
import struct
import time
import urllib.request
import zipfile
import zlib
from dataclasses import dataclass


def resolve_url(url: str) -> tuple[str, int]:
    """Follow redirects once (HF -> CDN) and return (final_url, size)."""
    req = urllib.request.Request(url, method="HEAD")
    with urllib.request.urlopen(req) as r:
        return r.url, int(r.headers["Content-Length"])


def _get_range(url: str, start: int, end: int, retries: int = 5) -> bytes:
    """Fetch bytes [start, end] inclusive, retrying transient errors."""
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"Range": f"bytes={start}-{end}"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.read()
        except Exception:  # noqa: BLE001 - network errors vary a lot
            if attempt == retries - 1:
                raise
            time.sleep(2**attempt)
    raise RuntimeError("unreachable")


class _RangeFile(io.RawIOBase):
    """Minimal seekable file over HTTP, used only to parse the central directory."""

    def __init__(self, url: str, size: int):
        self.url, self.size, self.pos = url, size, 0

    def seekable(self):
        return True

    def readable(self):
        return True

    def tell(self):
        return self.pos

    def seek(self, off, whence=0):
        self.pos = {0: off, 1: self.pos + off, 2: self.size + off}[whence]
        return self.pos

    def readinto(self, b):
        n = min(len(b), self.size - self.pos)
        if n <= 0:
            return 0
        data = _get_range(self.url, self.pos, self.pos + n - 1)
        b[: len(data)] = data
        self.pos += len(data)
        return len(data)


@dataclass
class Member:
    name: str
    header_offset: int
    compress_size: int
    compress_type: int


class RemoteZip:
    """List and read members of a zip file hosted at `url`."""

    def __init__(self, url: str):
        self.url, self.size = resolve_url(url)
        raw = io.BufferedReader(_RangeFile(self.url, self.size), buffer_size=4 << 20)
        with zipfile.ZipFile(raw) as zf:
            self.members = {
                i.filename: Member(i.filename, i.header_offset, i.compress_size, i.compress_type)
                for i in zf.infolist()
                if not i.is_dir()
            }

    def read(self, name: str) -> bytes:
        """Download and decompress one member."""
        m = self.members[name]
        # Local header is 30 bytes + filename + extra field. The local extra
        # field can differ from the central one, so over-fetch a little.
        slack = 30 + len(name.encode()) + 1024
        blob = _get_range(self.url, m.header_offset, m.header_offset + slack + m.compress_size)
        sig, *_rest = struct.unpack("<I", blob[:4])
        if sig != 0x04034B50:
            raise ValueError(f"bad local header for {name}")
        fn_len, extra_len = struct.unpack("<HH", blob[26:30])
        start = 30 + fn_len + extra_len
        data = blob[start : start + m.compress_size]
        if m.compress_type == zipfile.ZIP_STORED:
            return data
        if m.compress_type == zipfile.ZIP_DEFLATED:
            return zlib.decompress(data, -15)
        raise ValueError(f"unsupported compression {m.compress_type} for {name}")
