"""Prepare DeepFashion2 for detection training and retrieval evaluation.

Steps (each is idempotent, so re-running skips finished work):

1. ``--train-subset N``: pick N training images with a fixed seed, write the
   list to ``splits/df2_train_subset.txt``, and download only those images and
   annotations from the remote train.zip (HTTP range requests).
2. ``--val``: extract the local validation.zip, then split DF2-val *by pair_id*
   into ``det_val`` (checkpoint selection during training) and ``det_test``
   (final held-out numbers). Splitting by pair_id keeps photos of the same
   garment from landing on both sides.
3. ``--yolo``: write YOLO-format labels plus a dataset YAML for ultralytics.
4. ``--items``: write ``data/df2/val_items.csv`` (one row per garment) used by
   the consumer-to-shop retrieval evaluation.

Usage:
    python -m src.data.prepare_df2 --train-subset 15000 --val --yolo --items
"""
from __future__ import annotations

import argparse
import json
import os
import random
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pandas as pd
from PIL import Image
from tqdm import tqdm

from src.config import DF2, DF2_CLASSES, DF2_HF_BASE, DF2_RAW, SEED, SPLITS, YOLO_DS

TRAIN_LIST = SPLITS / "df2_train_subset.txt"
DET_VAL_LIST = SPLITS / "df2_det_val.txt"
DET_TEST_LIST = SPLITS / "df2_det_test.txt"


# ---------------------------------------------------------------------------
# 1. Training subset (remote, partial download)
# ---------------------------------------------------------------------------
def make_train_subset(n: int, workers: int = 16) -> list[str]:
    from src.data.remote_zip import RemoteZip

    print("Reading train.zip table of contents (remote)...")
    rz = RemoteZip(f"{DF2_HF_BASE}/train.zip")
    all_stems = sorted(
        Path(name).stem for name in rz.members if name.startswith("train/image/") and name.endswith(".jpg")
    )
    print(f"train.zip lists {len(all_stems):,} images")

    if TRAIN_LIST.exists():
        stems = TRAIN_LIST.read_text().split()
        print(f"Re-using existing subset list ({len(stems):,} images)")
    else:
        stems = sorted(random.Random(SEED).sample(all_stems, n))
        SPLITS.mkdir(parents=True, exist_ok=True)
        TRAIN_LIST.write_text("\n".join(stems) + "\n")
        print(f"Wrote {TRAIN_LIST} ({len(stems):,} images, seed={SEED})")

    out = DF2 / "train"
    (out / "image").mkdir(parents=True, exist_ok=True)
    (out / "annos").mkdir(parents=True, exist_ok=True)

    def fetch(stem: str) -> None:
        for sub, ext in (("image", "jpg"), ("annos", "json")):
            dst = out / sub / f"{stem}.{ext}"
            if dst.exists() and dst.stat().st_size > 0:
                continue
            tmp = dst.with_suffix(dst.suffix + ".part")
            tmp.write_bytes(rz.read(f"train/{sub}/{stem}.{ext}"))
            os.replace(tmp, dst)  # atomic, so an interrupted run never leaves half files

    with ThreadPoolExecutor(workers) as ex:
        list(tqdm(ex.map(fetch, stems), total=len(stems), desc="download train subset"))
    return stems


# ---------------------------------------------------------------------------
# 2. Validation extraction and pair-level split
# ---------------------------------------------------------------------------
def extract_val() -> None:
    dst = DF2 / "validation"
    if (dst / "annos").exists() and len(os.listdir(dst / "annos")) > 30000:
        print("validation already extracted")
        return
    DF2.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DF2_RAW / "validation.zip") as zf:
        for m in tqdm(zf.infolist(), desc="extract validation"):
            # Guard against path traversal in an untrusted archive.
            target = (DF2 / m.filename).resolve()
            if not str(target).startswith(str(DF2.resolve())):
                raise ValueError(f"unsafe path in zip: {m.filename}")
            zf.extract(m, DF2)


def load_annos(split_dir: Path, stems: list[str]) -> dict[str, dict]:
    return {s: json.loads((split_dir / "annos" / f"{s}.json").read_text()) for s in stems}


def split_val(n_det_val_pairs: int = 100, n_det_test_pairs: int = 400) -> None:
    """Assign whole pair_ids to det_val / det_test; the rest of DF2-val is unused for detection.
    The committed lists in splits/ are the source of truth and are never overwritten."""
    if DET_VAL_LIST.exists() and DET_TEST_LIST.exists():
        print(f"Using committed split lists: det_val={len(DET_VAL_LIST.read_text().split()):,}, "
              f"det_test={len(DET_TEST_LIST.read_text().split()):,} images")
        return
    vdir = DF2 / "validation"
    stems = sorted(p.stem for p in (vdir / "annos").glob("*.json"))
    annos = load_annos(vdir, stems)
    by_pair: dict[int, list[str]] = {}
    for s, a in annos.items():
        by_pair.setdefault(a["pair_id"], []).append(s)
    pairs = sorted(by_pair)
    rng = random.Random(SEED)
    rng.shuffle(pairs)
    val_pairs = pairs[:n_det_val_pairs]
    test_pairs = pairs[n_det_val_pairs : n_det_val_pairs + n_det_test_pairs]
    det_val = sorted(s for p in val_pairs for s in by_pair[p])
    det_test = sorted(s for p in test_pairs for s in by_pair[p])
    SPLITS.mkdir(parents=True, exist_ok=True)
    DET_VAL_LIST.write_text("\n".join(det_val) + "\n")
    DET_TEST_LIST.write_text("\n".join(det_test) + "\n")
    print(f"DF2-val: {len(stems):,} images in {len(pairs):,} pairs")
    print(f"det_val : {len(det_val):,} images from {len(val_pairs)} pairs")
    print(f"det_test: {len(det_test):,} images from {len(test_pairs)} pairs")


# ---------------------------------------------------------------------------
# 3. YOLO conversion
# ---------------------------------------------------------------------------
def anno_to_yolo(anno: dict, w: int, h: int) -> list[str]:
    """Convert one DF2 annotation dict to YOLO lines: 'cls cx cy bw bh' (normalized)."""
    lines = []
    for key, item in anno.items():
        if not key.startswith("item"):
            continue
        x1, y1, x2, y2 = item["bounding_box"]
        x1, x2 = max(0, x1), min(w, x2)
        y1, y2 = max(0, y1), min(h, y2)
        if x2 <= x1 or y2 <= y1:
            continue
        cls = item["category_id"] - 1
        cx, cy = (x1 + x2) / 2 / w, (y1 + y2) / 2 / h
        lines.append(f"{cls} {cx:.6f} {cy:.6f} {(x2 - x1) / w:.6f} {(y2 - y1) / h:.6f}")
    return lines


def write_yolo_split(name: str, src_dir: Path, stems: list[str]) -> None:
    img_out = YOLO_DS / "images" / name
    lbl_out = YOLO_DS / "labels" / name
    img_out.mkdir(parents=True, exist_ok=True)
    lbl_out.mkdir(parents=True, exist_ok=True)
    for s in tqdm(stems, desc=f"yolo {name}"):
        src_img = (src_dir / "image" / f"{s}.jpg").resolve()
        link = img_out / f"{s}.jpg"
        if not link.exists():
            link.symlink_to(src_img)  # symlink instead of copying images
        with Image.open(src_img) as im:
            w, h = im.size
        anno = json.loads((src_dir / "annos" / f"{s}.json").read_text())
        (lbl_out / f"{s}.txt").write_text("\n".join(anno_to_yolo(anno, w, h)) + "\n")


def write_yolo() -> None:
    write_yolo_split("train", DF2 / "train", TRAIN_LIST.read_text().split())
    write_yolo_split("val", DF2 / "validation", DET_VAL_LIST.read_text().split())
    write_yolo_split("test", DF2 / "validation", DET_TEST_LIST.read_text().split())
    names = "\n".join(f"  {i}: {c}" for i, c in enumerate(DF2_CLASSES))
    (YOLO_DS / "df2.yaml").write_text(
        f"path: {YOLO_DS.resolve()}\ntrain: images/train\nval: images/val\ntest: images/test\nnames:\n{names}\n"
    )
    print(f"Wrote {YOLO_DS / 'df2.yaml'}")


# ---------------------------------------------------------------------------
# 4. Item table for retrieval evaluation
# ---------------------------------------------------------------------------
def write_val_items() -> None:
    vdir = DF2 / "validation"
    rows = []
    for p in tqdm(sorted((vdir / "annos").glob("*.json")), desc="val items"):
        a = json.loads(p.read_text())
        for key, item in a.items():
            if not key.startswith("item"):
                continue
            x1, y1, x2, y2 = item["bounding_box"]
            rows.append(
                dict(
                    image=p.stem,
                    item=key,
                    source=a["source"],  # "user" (consumer photo) or "shop"
                    pair_id=a["pair_id"],
                    style=item["style"],  # 0 = no consumer-shop correspondence
                    category_id=item["category_id"],
                    category=DF2_CLASSES[item["category_id"] - 1],
                    x1=x1, y1=y1, x2=x2, y2=y2,
                    occlusion=item["occlusion"],
                    zoom_in=item["zoom_in"],
                    viewpoint=item["viewpoint"],
                    scale=item["scale"],
                )
            )
    df = pd.DataFrame(rows)
    df.to_csv(DF2 / "val_items.csv", index=False)
    print(f"Wrote {DF2 / 'val_items.csv'}: {len(df):,} items")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--train-subset", type=int, default=0, help="download N training images (0 = skip)")
    ap.add_argument("--val", action="store_true", help="extract validation.zip and make det_val/det_test")
    ap.add_argument("--yolo", action="store_true", help="write YOLO labels + df2.yaml")
    ap.add_argument("--items", action="store_true", help="write val_items.csv for retrieval eval")
    ap.add_argument("--workers", type=int, default=16, help="parallel HTTP requests for --train-subset")
    args = ap.parse_args()
    if args.train_subset:
        make_train_subset(args.train_subset, workers=args.workers)
    if args.val:
        extract_val()
        split_val()
    if args.yolo:
        write_yolo()
    if args.items:
        write_val_items()


if __name__ == "__main__":
    main()
