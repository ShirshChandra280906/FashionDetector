"""Build the product catalog used for retrieval.

Source: the Kaggle "Fashion Product Images" dataset (paramaggarwal), via two
Hugging Face mirrors:
  * ashraq/fashion-product-images-small -> metadata (articleType, colour, ...)
  * ceyda/fashion-products-small        -> the same products at up to 512 px
We join them on product id, keep apparel whose articleType maps onto one of
our retrieval groups, and write data/catalog/catalog.csv + images/{id}.jpg.

Usage:
    python -m src.data.prepare_catalog
"""
from __future__ import annotations

import io
from collections import Counter

import pandas as pd
from PIL import Image
from tqdm import tqdm

from src.config import CATALOG, GROUPS, RAW

# articleType -> retrieval group. Innerwear, loungewear, nightwear, ethnic sets
# (saree, lehenga) and jumpsuits have no DeepFashion2 counterpart and are left out.
ARTICLE_TO_GROUP = {
    # tops
    "Tshirts": "top", "Shirts": "top", "Tops": "top", "Tunics": "top",
    "Sweaters": "top", "Sweatshirts": "top", "Kurtas": "top", "Kurtis": "top",
    # outerwear
    "Jackets": "outerwear", "Blazers": "outerwear", "Shrug": "outerwear",
    "Rain Jacket": "outerwear", "Nehru Jackets": "outerwear",
    # bottoms
    "Shorts": "shorts",
    "Trousers": "trousers", "Jeans": "trousers", "Track Pants": "trousers",
    "Capris": "trousers", "Leggings": "trousers", "Jeggings": "trousers",
    "Tights": "trousers", "Patiala": "trousers", "Salwar": "trousers",
    "Churidar": "trousers",
    "Skirts": "skirt",
    # dresses
    "Dresses": "dress",
}
KEEP_SUBCATEGORIES = {"Topwear", "Bottomwear", "Dress"}


def load_parquets(folder) -> pd.DataFrame:
    return pd.concat([pd.read_parquet(p) for p in sorted(folder.glob("*.parquet"))], ignore_index=True)


def main() -> None:
    meta = load_parquets(RAW / "catalog_meta").drop(columns=["image"])
    imgs = load_parquets(RAW / "catalog_img")[["id", "image"]]
    imgs["id"] = imgs["id"].astype(int)
    print(f"metadata rows: {len(meta):,} | hi-res image rows: {len(imgs):,}")

    df = meta.merge(imgs, on="id", how="inner")
    print(f"joined on id: {len(df):,}")

    apparel = df[df["subCategory"].isin(KEEP_SUBCATEGORIES)].copy()
    apparel["group"] = apparel["articleType"].map(ARTICLE_TO_GROUP)
    skipped = Counter(apparel.loc[apparel["group"].isna(), "articleType"])
    print("articleTypes skipped (no DF2 counterpart):", dict(skipped.most_common()))
    cat = apparel.dropna(subset=["group"]).reset_index(drop=True)

    img_dir = CATALOG / "images"
    img_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for row in tqdm(cat.itertuples(), total=len(cat), desc="write images"):
        out = img_dir / f"{row.id}.jpg"
        if not out.exists():
            # Re-encode through PIL: normalises format/mode and rejects corrupt bytes.
            Image.open(io.BytesIO(row.image["bytes"])).convert("RGB").save(out, quality=92)
        paths.append(f"images/{row.id}.jpg")
    cat["image_path"] = paths

    cols = ["id", "group", "articleType", "subCategory", "gender", "baseColour",
            "season", "usage", "productDisplayName", "image_path"]
    cat[cols].to_csv(CATALOG / "catalog.csv", index=False)
    print(f"\nWrote {CATALOG / 'catalog.csv'}: {len(cat):,} products")
    print(cat["group"].value_counts().reindex(GROUPS).to_string())


if __name__ == "__main__":
    main()
